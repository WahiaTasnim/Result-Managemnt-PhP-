<?php 
include_once('bootstrap.php');
include_once('connection.php');
include_once('function.php');
/*if($conn->connect_error)
{
die("connection failed".$conn->connect_error);
}
 
 else
 {
 	echo "connected successfully";
 }*/
login();

 ?>



<div class="container">
	<?php 
if(isset($error)){
echo "<h3 class='alert alert-danger text-center'>".$error."</h3>";

}

 if(isset($success)){
      echo "<h3 class='alert alert-success text-center'>".$success."</h3>";
    }

	 ?>
	<h2 class="text-center mb-5 btn-success py-3">LogIn Form</h2>
	<div class="login_form m-auto col-md-6">

		<form action="" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Email Address</label>
				<input type="email" name="email" class="form-control">
			</div>
			
			<div class="form-group">
				<label for="">Password</label>
				<input type="password" name="pass" class="form-control">
			</div>
			
			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-success px-5" value="LogIn">
				<a href="" style="margin-left:130px">Are you registered?</a>
				<a href="reg.php" class="btn btn-info float-right">Registration</a>
			</div>
			
		</form>
	</div>

</div>



<?php 
include_once('footer.php');
 ?>


