<?php 

include_once('bootstrap.php');
include_once('function.php');
include_once('connection.php');
session_start();
if(empty($_SESSION['roll'])||empty($_SESSION['board']))
{
	header('location:search.php');
}
$roll= $_SESSION['roll'];
$board= $_SESSION['board'];
$data = $conn->query("select * from student_info where board='$board' and roll=$roll");


 ?>

<div class="container">
	<h2 class="text-center bg-success p-2 mb-4">HSC RESULT 2020(FAKE)</h2>
	<?php  while($dt= $data->fetch_assoc()){?>
		<div class="showResult">
<div style="margin-left: 34%;">
			<h4>Candidate Name: <?php echo $dt['name']; ?></h4>
				<h4>Mother Name: <?php echo $dt['fname']; ?></h4>
					<h4>Mother Name: <?php echo $dt['mname']; ?></h4>
						<h4>Institution Name: <?php echo $dt['inst']; ?></h4>
							<h4>Roll: <?php echo $dt['roll']; ?></h4>
								<h4>Board Name: <?php echo $dt['board']; ?></h4>
									<h4>GPA: <?php echo $dt['f_gpa']; ?></h4>
										<h4>Grade: <?php echo $dt['f_grade']; ?></h4>
									</div>
									
			<h4 class="text-center bg-primary p-2 mb-4">Result Sheet</h4>
			<div style="margin-left: 34%;">
			<h5>Bangla: <?php echo $dt['bangla_g']; ?></h5>
			<h5>English: <?php echo $dt['english_g']; ?></h5>
			<h5>Math: <?php echo $dt['math_g']; ?></h5>	
			<h5>Social: <?php echo $dt['social_g']; ?></h5>	
			<h5>Science: <?php echo $dt['science_g']; ?></h5>
			<h5>Religion: <?php echo $dt['religion_g']; ?></h5>	
			</div>			
		</div>


	<?php }?>
	<div class="text-center mt-5">
	<a href="back.php" class="btn btn-primary">Search Again</a>
</div>
</div>


 <?php 
include_once('footer.php');
 ?>