<?php 
include_once('bootstrap.php');
include_once('function.php');
include_once('connection.php');


if(isset($_POST['submit'])){
	$board=$_POST['board'];
	$roll=$_POST['roll'];
if(empty($board)&&empty($roll))
{
$error="Fields must not be empty";

}
else if(empty($board))
{
	$error="Board can not be empty";
}
else if(empty($roll))
{
	$error="Roll can not be empty";
}
else{
$data = $conn->query("select * from student_info where board='$board' and roll=$roll");
session_start();
$row=$data->num_rows;
if($row==1){
	$_SESSION['roll']=$roll;
	$_SESSION['board']=$board;
header('location:result.php');
}
else
{
	$error="Insert valid roll and board";
}
}
}
 ?>



<div class="container">
	<h2 class="text-center bg-primary p-2 mb-5">HSC RESULT 2020(FAKE)</h2>
	<?php 
if(isset($error)){
echo "<h3 class='alert alert-danger text-center'>".$error."</h3>";

}

 if(isset($success)){
      echo "<h3 class='alert alert-success text-center'>".$success."</h3>";
    }

	 ?>
	<form action="" class="w-50 m-auto" method="post">
		<div class="form-group">
<div class="row">
			<label for="" class="col-md-3">Enter Roll</label>
			<input type="text" class="form-control col-md-6" name="roll">
		</div>
		</div>
		<div class="form-group">
<div class="row">
			<label for="" class="col-md-3">Enter Board</label>
			<select name="board" id="" class="form-control col-md-6">
 						<option value="">--Select--</option>
 						<option value="Dhaka">Dhaka</option>
 						<option value="Mymensingh">Mymensingh</option>
 						<option value="Cumilla">Cumilla</option>
 						<option value="Rajshahi">Rajshahi</option>
 						<option value="Dinajpur">Dinajpur</option>
 						<option value="Chittagong">Chittagong</option>
 						<option value="Jessore">Jessore</option>
 						<option value="Barishal">Barishal</option>
 					</select>
		</div>
		</div>
		<div class="form-group text-center">
			<input type="submit" class="btn btn-primary" value="search" name="submit">
		</div>
	</form>
</div>

 <?php 
include_once('footer.php');
 ?>