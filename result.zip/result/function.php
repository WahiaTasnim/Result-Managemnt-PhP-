<?php 
include_once('connection.php');
//include_once('index.php');
function insertData(){
	global $conn;
	if(isset($_POST['submit']))
 {
 	//echo "ok";
 	$fname= $_POST['fname'];
 	$lname= $_POST['lname'];
 	$email= $_POST['email'];
 	$gender= $_POST['gender'];
 	$pass= $_POST['pass'];
 	$conpass= $_POST['conpass'];
 	$image= $_FILES['image']['name'];
 	$img_tmp_name =$_FILES['image']['tmp_name'];
 	$img_name_array= explode('.',$image);
 	$ext = end($img_name_array);
 	$img_final_name= time().md5($image).".".$ext;
$data = $conn->query("select * from reg_info where email = '$email' and pass = '$pass'");
    $row = $data->num_rows;
 	if(empty($fname)|| empty($lname) || empty($email) || empty($pass) || empty($conpass))
 	{
 		$error="Feilds must not be empty";
 	}
 	else if ($pass != $conpass)
 	{
 		$error = "Password doesn't match";
 	}
  else if($row>0)
    {
      $error= "You are already registered!";
      echo $error;
    }
 	else if(in_array($ext, ['jpg','png','gif','jpeg'])==false){
  		$error= "Image is invalid";
  	}
  	else
  	{
  		$conn->query("insert into reg_info(fname,lname,email,gender,pass,image) values('$fname','$lname','$email','$gender','$pass','$img_final_name')");
  		move_uploaded_file($img_tmp_name, 'images/'.$img_final_name);
  		$success =  "Data inserted successfully";
      header('location:login.php');
  	}
  	
 	
 }
}

function login(){
	global $conn;
	if(isset($_POST['submit'])){
  	session_start();
  	$pass= $_POST['pass'];
  	$email= $_POST['email'];
  	$data = $conn->query("select * from reg_info where email = '$email' and pass = '$pass'");
  	$row = $data->num_rows;
  	if(empty($email) || empty($pass )){
  		$error= "Field must not be empty";
  		//echo $error;
  	}
  	else if($row>0){
  		$_SESSION['email'] = $email;
  		$_SESSION['pass'] = $pass;
  		while($dt= $data->fetch_assoc()){
  			$_SESSION['fname'] = $dt['fname'];
  		$_SESSION['lname'] = $dt['lname'];
  		$_SESSION['image'] = $dt['image'];
  		//$_SESSION['pass'] = $pass;
  		}
  		header('location:profile.php');
  		//echo "You are logged in";

  	}
  	else{
  		//header('location:login.php');
  		$error = "user is not found! please check email or password";
  		header('location:login.php');
  	}
  	
  }
}

function student_grade_point($num)
{
  if($num>=0 && $num<33)
  {
    $grade=0;
    $gp="F";
  }
  else if($num>=33 && $num<40){
    $grade=1;
    $gp="D";
  }
   else if($num>=40 && $num<50){
    $grade=2;
    $gp="C";
  }
   else if($num>=50 && $num<60){
    $grade=3;
    $gp="B";
  }
   else if($num>=60 && $num<70){
    $grade=3.5;
    $gp="A-";
  }
   else if($num>=70 && $num<80){
    $grade=4;
    $gp="A";
  }
   else if($num>=80 && $num<100){
    $grade=5;
    $gp="A+";
  }
  else
  {
    $grade=0;
    $gp="Invalid";
  }
  return $grade;
}
function student_grade($num)
{
  if($num>=0 && $num<33)
  {
    $grade=0;
    $gp="F";
  }
  else if($num>=33 && $num<40){
    $grade=1;
    $gp="D";
  }
   else if($num>=40 && $num<50){
    $grade=2;
    $gp="C";
  }
   else if($num>=50 && $num<60){
    $grade=3;
    $gp="B";
  }
   else if($num>=60 && $num<70){
    $grade=3.5;
    $gp="A-";
  }
   else if($num>=70 && $num<80){
    $grade=4;
    $gp="A";
  }
   else if($num>=80 && $num<100){
    $grade=5;
    $gp="A+";
  }
  else
  {
    $grade=0;
    $gp="Invalid";
  }
  return $gp;
}

 ?>