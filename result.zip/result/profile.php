<?php 
include_once('bootstrap.php');
include_once('function.php');
include_once('connection.php');
session_start();
if(empty($_SESSION['email'])|| empty($_SESSION['pass']))
{
	header('location:login.php');
}

	//$_SESSION
if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$mname=$_POST['mname'];
	$fname=$_POST['fname'];
	$roll=$_POST['roll'];
	$bangla=$_POST['bangla'];
	$english=$_POST['english'];
	$math=$_POST['math'];
	$inst=$_POST['institution'];
	$board=$_POST['board'];
	$science=$_POST['science'];
$social=$_POST['social-science'];
$religion=$_POST['religion'];
	//echo $f_grade;

	if(empty($name)||empty($mname)||empty($fname)||empty($inst)||empty($board)||empty($roll)||empty($bangla)||empty($social)||empty($science)||empty($religion)){
		$error="Fields must not be empty";
	}
	else{
		$bangla_gp=student_grade_point($bangla);
	$bangla_g=student_grade($bangla);
	$english_gp=student_grade_point($english);
	$english_g=student_grade($english);
	$math_gp=student_grade_point($math);
	$math_g=student_grade($math);
	$science_gp=student_grade_point($science);
	$science_g=student_grade($science);
	$social_gp=student_grade_point($social);
	$social_g=student_grade($social);
	$religion_gp=student_grade_point($religion);
	$religion_g=student_grade($religion);
	$total_marks=$bangla+$english+$math+$science+$social+$religion;
	$f_gpa=($bangla_gp+$english_gp+$math_gp+$science_gp+$social_gp+$religion_gp);
	$f_grade=student_grade($total_marks/6);
$conn->query("insert into student_info (
name,
mname,
roll,
bangla,
english,
math,
fname,
inst,
board,
science,
religion,
bangla_g,
social,
bangla_gp,
english_g,
english_gp,
math_g,
math_gp,
science_g,
science_gp,
social_g,
social_gp,
religion_g,
religion_gp,
total_marks,
f_gpa,
f_grade) values(
'$name',
'$mname',
$roll,
$bangla,
$english,
$math,
'$fname',
'$inst',
'$board',
$science,
$religion,
'$bangla_g',
$social,
$bangla_gp,
'$english_g',
$english_gp,
'$math_g',
$math_gp,
'$science_g',
$science_gp,
'$social_g',
$social_gp,
'$religion_g',
$religion_gp,
$total_marks,
'$f_gpa',
'$f_grade')");
$success =  "Data inserted successfully";
}
}

 ?>

<div class="container">
	<ul class="list-unstyled list-inline bg-info text-light">
		<li class="list-inline-item"><img style="height:100px; width:100px;" src="images/<?php echo $_SESSION['image']?>" alt=""></li>
		<li class="list-inline-item"style="font-size:17px;"><?php echo $_SESSION['fname']." ".$_SESSION['lname']; ?></li>
		<li class="list-inline-item" style="margin-left: 54%;"><a href="logout.php" class="btn btn-danger">Log Out</a></li>
	</ul>
	
	
</div>
 
 <div class="container mt-4">
 	
 	<h2 class="text-center">Enter Student Result Information</h2>
 	<hr>
<?php 
if(isset($error)){
echo "<h3 class='alert alert-danger text-center'>".$error."</h3>";

}

 if(isset($success)){
      echo "<h3 class='alert alert-success text-center'>".$success."</h3>";
    }

	 ?>
<form action="" method="post">
 	<div class="row">
 			
 			<div class="col-md-6">
 				<div class="form-group">
 					<label for="">Name</label>
 					<input type="text" class="form-control" name="name">
 				</div>
 				<div class="form-group">
 					<label for="">Mother Name</label>
 					<input type="text" class="form-control" name="mname">
 				</div>
 				<div class="form-group">
 					<label for="">Roll</label>
 					<input type="text" class="form-control" name="roll">
 				</div>
 				<div class="form-group">
 					<label for="">Bangla</label>
 					<input type="text" class="form-control" name="bangla">
 				</div>
 				<div class="form-group">
 					<label for="">English</label>
 					<input type="text" class="form-control" name="english">
 				</div>
 				<div class="form-group">
 					<label for="">Mathmatics</label>
 					<input type="text" class="form-control" name="math">
 				</div>
 			</div>
 			<div class="col-md-6">
 				<div class="form-group">
 					<label for="">Father Name</label>
 					<input type="text" class="form-control" name="fname">
 				</div>
 				<div class="form-group">
 					<label for="">Institution</label>
 					<input type="text" class="form-control" name="institution">
 				</div>
 				<div class="form-group">
 					<label for="">Board</label>
 					<select name="board" id="" class="form-control">
 						<option value="select">--Select--</option>
 						<option value="Dhaka">Dhaka</option>
 						<option value="Mymensingh">Mymensingh</option>
 						<option value="Cumilla">Cumilla</option>
 						<option value="Rajshahi">Rajshahi</option>
 						<option value="Dinajpur">Dinajpur</option>
 						<option value="Chittagong">Chittagong</option>
 						<option value="Jessore">Jessore</option>
 						<option value="Barishal">Barishal</option>
 					</select>
 				</div>
 				<div class="form-group">
 					<label for="">Science</label>
 					<input type="text" class="form-control" name="science">
 				</div>
 				<div class="form-group">
 					<label for="">Social Science</label>
 					<input type="text" class="form-control" name="social-science">
 				</div>
 				<div class="form-group">
 					<label for="">Religion</label>
 					<input type="text" class="form-control" name="religion">
 				</div>
 			</div>

 			<div class="col-md-4">
 				<input type="submit" class="btn btn-success" name="submit">
 			</div>
 	</div>
 	</form>
 </div>



 <?php 
include_once('footer.php');
 ?>