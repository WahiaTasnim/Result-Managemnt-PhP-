<?php 
include_once('bootstrap.php');
include_once('connection.php');
include_once('function.php');
/*if($conn->connect_error)
{
die("connection failed".$conn->connect_error);
}
 
 else
 {
 	echo "connected successfully";
 }*/
insertData();

 ?>



<div class="container">
	<?php 
if(isset($error)){
echo "<h3 class='alert alert-danger text-center'>".$error."</h3>";

}

 if(isset($success)){
      echo "<h3 class='alert alert-success text-center'>".$success."</h3>";
    }

	 ?>
	<h2 class="text-center mb-5 btn-success py-3">Registration Form</h2>
	<div class="reg_form m-auto col-md-6">

		<form action="" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">First Name</label>
				<input type="text" name="fname" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Last Name</label>
				<input type="text" name="lname" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Email Address</label>
				<input type="email" name="email" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Gender</label>
				<input type="radio" name="gender" value="male" class="mx-3">Male
				<input type="radio" name="gender" value="female" class="mx-3">Female

			</div>
			<div class="form-group">
				<label for="">Password</label>
				<input type="password" name="pass" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Confirm Password</label>
				<input type="password" name="conpass" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Image</label>
				<input type="file" name="image" class="form-control">
			</div>
			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-success  px-5">
				<a href="" style="margin-left:100px">Are you already registered?</a>
				<a href="login.php" class="btn btn-info float-right">LogIn</a>
			</div>

		</form>
	</div>

</div>



<?php 
include_once('footer.php');
 ?>


